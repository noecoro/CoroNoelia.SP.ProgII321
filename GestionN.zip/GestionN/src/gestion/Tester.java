package gestion;
import java.io.IOException;
//import util.CSVSerializable;

import modelo.Inventario;
import modelo.Categoria;
import modelo.NaveEspacial;
public class Tester {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        
         try {
        // Crear un inventario de naves espaciales
        Inventario<NaveEspacial> inventarioNaves = new Inventario<>();
        inventarioNaves.agregar(new NaveEspacial(1, "USS Enterprise", 50, Categoria.CIENTIFICA));
        inventarioNaves.agregar(new NaveEspacial(2, "Millennium Falcon", 3, Categoria.TRANSPORTE));
        inventarioNaves.agregar(new NaveEspacial(3, "TIE Fighter", 1, Categoria.MILITAR));
        inventarioNaves.agregar(new NaveEspacial(4, "X-Wing", 2, Categoria.MILITAR));
        inventarioNaves.agregar(new NaveEspacial(5, "Discovery One", 100, Categoria.CIENTIFICA));
        inventarioNaves.agregar(new NaveEspacial(6, "Nave 6", 100, Categoria.CIENTIFICA));

         //ELIMINAAR
        int idEliminar = 5;
        inventarioNaves.eliminar(libro -> libro.getId() == idEliminar);
        System.out.println("____===__LA NAVE con ID  " + idEliminar + " FUE ELIMINADA _____");
        
        
        // Mostrar todas las naves en el inventario
        System.out.println("Inventario de naves espaciales:");
        inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

        // Filtrar naves por categorIa MILITAR
        System.out.println("\n_______Naves de la categorIa MILITAR:");
        inventarioNaves.filtrar(nave -> nave.getCategoria() == Categoria.MILITAR)
                .forEach(nave -> System.out.println(nave));

        // Filtrar naves cuyo nombre contiene "Falcon"
        System.out.println("\n_____Naves cuyo nombre contiene 'Falcon':");
        inventarioNaves.filtrar(nave -> nave.getNombre().contains("Falcon"))
                .forEach(nave -> System.out.println(nave));

        // Ordenar naves de manera natural (por ID)
        System.out.println("\n__________Naves ordenadas de manera natural (por ID):");
        inventarioNaves.ordenar();
        inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

        // Ordenar naves por tripulación utilizando un Comparator
        System.out.println("\n_____ Naves ordenadas por tripulacion:");// asc
        inventarioNaves.ordenar((nave1, nave2) -> Integer.compare(nave1.getCapacidadTripulacion(), nave2.getCapacidadTripulacion()));
        inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

        // Guardar el inventario en un archivo binario
        inventarioNaves.guardarEnArchivo("src/data/naves.dat");

        // Cargar el inventario desde el archivo binario
        Inventario<NaveEspacial> inventarioCargado = new Inventario<>();
        inventarioCargado.cargarDesdeArchivo("src/data/naves.dat");
        System.out.println("\n_____== Naves cargadas desde archivo binario:");
        inventarioCargado.paraCadaElemento(nave -> System.out.println(nave));

        // Guardar el inventario en un archivo CSV
        inventarioNaves.guardarEnCSV("src/data/naves.csv");


        // Cargar el inventario desde el archivo CSV
        inventarioCargado.cargarDesdeCSV("src/data/naves.csv", linea -> NaveEspacial.fromCSV(linea));
        System.out.println("\n____ Naves cargadas desde archivo CSV:");
        inventarioCargado.paraCadaElemento(nave -> System.out.println(nave));

    } catch (IOException e) {
        System.err.println("Error: " + e.getMessage());
    }
      
        
    }
}

