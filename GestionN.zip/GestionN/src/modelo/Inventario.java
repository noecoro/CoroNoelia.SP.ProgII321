package modelo;

import Service.Serializadora;
import java.io.*;
import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;

import java.io.IOException;

import java.io.BufferedReader;
import java.util.function.Consumer;
import util.CSVSerializable;

public class Inventario<T extends Serializable & Comparable<T>> {
    private List<T> items = new ArrayList<>();

    public void agregar(T item) {
        if (item == null) {
            throw new IllegalArgumentException("No se puede agregar un elemento nulo.");
        }
        items.add(item);
    }

    public void eliminar(Predicate<T> criterio) {
        items.removeIf(criterio);
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        items.forEach(accion);
    }

    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T item : items) {
            if (criterio.test(item)) {
                resultado.add(item);
            }
        }
        return resultado;
    }

    public void ordenar() {
        Collections.sort(items);
    }

    public void ordenar(Comparator<? super T> comparator) {
        items.sort(comparator);
    }

    public void transformar(Function<T, T> transformador) {
        ListIterator<T> iterador = items.listIterator();
        while (iterador.hasNext()) {
            iterador.set(transformador.apply(iterador.next()));
        }
    }
    
    // =========== binario
public void guardarEnArchivo(String path) throws IOException {
    try {
        Serializadora.serializarLista(items, path); 
        System.out.println("Inventario guardado en el archivo binario: " + path);
    } catch (Exception ex) {
        System.out.println("Error al guardar en archivo binario: " + ex.getMessage());
    }
}

public void cargarDesdeArchivo(String path)throws IOException, ClassNotFoundException{ 
    try {
        List<T> elementosCargados = Serializadora.deserializarLista(path);
        if (elementosCargados != null) {
            items.clear(); 
            items.addAll(elementosCargados); 
            System.out.println("\n Inventario cargado desde el archivo binario: " + path);
        } else {
            System.out.println("El archivo binario est vacio o no se pudo cargar.");
        }
    } catch (Exception ex) {
        System.out.println("Error al cargar desde archivo binario: " + ex.getMessage());
    }
}
//==============
public void guardarEnCSV(String path) throws IOException{
    File archivo = new File(path);

    try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
       
        bw.write("id,nombre,tripulacion,categoria\n");

        
        for (T item : items) {
            if (item instanceof CSVSerializable) { 
                bw.write(((CSVSerializable) item).toCSV() + "\n");
            }
        }

        System.out.println("\n Inventario guardado en CSV: " + path);
    } catch (IOException ex) {
        System.out.println("Error al guardar en CSV: " + ex.getMessage());
    }
}

public void cargarDesdeCSV(String path, Function<String, T> convertidor) throws IOException {
    File archivo = new File(path);

    try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
        String linea;
      
        br.readLine(); 
        while ((linea = br.readLine()) != null) {
            if (linea != null && !linea.trim().isEmpty()) { 
                try {
                    T item = convertidor.apply(linea); 
                    agregar(item);
                } catch (IllegalArgumentException e) {
                    System.out.println("Error al procesar linea: " + linea + " - " + e.getMessage());
                }
            }
        }
        System.out.println("Inventario cargado desde el archivo CSV.");
    } catch (IOException e) {
        System.out.println("Error al leer el archivo CSV: " + e.getMessage());
        throw e; 
    }
}

}

