package modelo;

import java.io.Serializable;
import util.CSVSerializable;

public class NaveEspacial implements Comparable<NaveEspacial>, Serializable {
    private int id;
    private String nombre;
   
    private int capacidadTripulacion;
     private Categoria categoria;

    public NaveEspacial(int id, String nombre,int capacidadTripulacion,Categoria categoria) {
       this.id = id;
        this.nombre = nombre;
       
        this.capacidadTripulacion = capacidadTripulacion;
        
         this.categoria = categoria;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

  

    public int getCapacidadTripulacion() {
        return capacidadTripulacion;
    }
  public Categoria getCategoria() {
        return categoria;
    }

    @Override
    public String toString() {
        return "NaveEspacial{" + "id=" + id + ", nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", categoria=" + categoria + '}';
    }
 

     @Override
    public int compareTo(NaveEspacial o) {
        return Integer.compare(this.id, o.id); // Ordenar por ID de manera natural
    }

     public String toCSV() {
        return id + "," + nombre + "," + capacidadTripulacion + "," + categoria.name();
    }

     
     public static NaveEspacial fromCSV(String csvLine) {
    String[] values = csvLine.split(",");
    if (values.length != 4) {
        throw new IllegalArgumentException("La línea CSV debe tener 4 valores: id, nombre, capacidadTripulacion, categoria.");
    }

    int id = Integer.parseInt(values[0].trim());
    String nombre = values[1].trim();
    int capacidadTripulacion = Integer.parseInt(values[2].trim());
    Categoria categoria = Categoria.valueOf(values[3].trim().toUpperCase());

    return new NaveEspacial(id, nombre, capacidadTripulacion, categoria);
}


}


